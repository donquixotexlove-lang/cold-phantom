# BRKH Konveksi — Website Statis

## Isi proyek
- `index.html` — halaman utama
- `style.css` — gaya tambahan
- `script.js` — interaksi menu, pencarian produk, formulir pengajuan, dan demo pelacakan

## Cara menjalankan
Buka `index.html` di browser, atau jalankan server lokal (misalnya Live Server di VS Code).

## Cara deploy
Folder ini dapat diunggah langsung sebagai static site ke Netlify, Vercel, atau GitHub Pages.
Pastikan `index.html`, `style.css`, dan `script.js` berada di direktori publik/root hasil deploy.

## Yang perlu disiapkan sebelum website digunakan publik
1. **Nomor WhatsApp BRKH:** buka `script.js`, cari `const whatsappNumber = '';`, lalu isi nomor resmi dalam format internasional tanpa tanda `+` atau spasi (contoh format Indonesia: `62812xxxxxxx`).
2. **Pelacakan pesanan:** fitur pada versi ini masih berupa demo/notifikasi. Pelacakan status pesanan sungguhan memerlukan backend dan database.
3. **Kontak dan identitas bisnis:** perbarui informasi WhatsApp, email, Instagram, alamat, logo, foto, serta katalog agar sesuai data resmi BRKH.
4. **Koneksi internet:** halaman memakai Tailwind CSS CDN dan Google Fonts, sehingga koneksi internet diperlukan agar seluruh tampilan/font eksternal termuat.

Catatan: paket ini mempertahankan HTML, CSS, dan JavaScript sebagai file terpisah agar mudah dirawat dan langsung cocok untuk hosting statis.

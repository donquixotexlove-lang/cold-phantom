/* BRKH Konveksi — interactions */
document.addEventListener('DOMContentLoaded', () => {
  // Mobile navigation
  const mobileBtn = document.getElementById('mobile-menu-button');
  const mobileMenu = document.getElementById('mobile-menu');

  if (mobileBtn && mobileMenu) {
    mobileBtn.addEventListener('click', () => {
      const isOpen = !mobileMenu.classList.contains('hidden');
      mobileMenu.classList.toggle('hidden');
      mobileBtn.setAttribute('aria-expanded', String(!isOpen));
      mobileBtn.setAttribute('aria-label', isOpen ? 'Buka Menu' : 'Tutup Menu');
    });

    mobileMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
        mobileBtn.setAttribute('aria-expanded', 'false');
        mobileBtn.setAttribute('aria-label', 'Buka Menu');
      });
    });
  }

  // Product search
  const searchInput = document.getElementById('product-search');
  if (searchInput) {
    const productCards = document.querySelectorAll('#katalog .grid > div');
    searchInput.addEventListener('input', event => {
      const term = event.target.value.trim().toLocaleLowerCase('id');
      productCards.forEach(card => {
        const title = card.querySelector('h3')?.textContent.toLocaleLowerCase('id') || '';
        const description = card.querySelector('p')?.textContent.toLocaleLowerCase('id') || '';
        card.classList.toggle('product-card-hidden', !(title.includes(term) || description.includes(term)));
      });
    });
  }

  // Order inquiry form: validate and prepare a WhatsApp message.
  const orderForm = document.querySelector('#pengajuan form');
  if (orderForm) {
    orderForm.addEventListener('submit', event => {
      event.preventDefault();
      if (!orderForm.reportValidity()) return;

      const product = orderForm.querySelector('input[name="product_type"]:checked')?.value || 'Belum dipilih';
      const quantity = document.getElementById('order-quantity')?.value.trim() || '-';
      const name = document.getElementById('client-name')?.value.trim() || '-';
      const contact = document.getElementById('client-contact')?.value.trim() || '-';
      const notes = document.getElementById('order-notes')?.value.trim() || '-';

      const message = [
        'Halo BRKH Konveksi, saya ingin mengajukan pesanan.',
        '',
        `Nama/Instansi: ${name}`,
        `Nomor WhatsApp: ${contact}`,
        `Jenis produk: ${product}`,
        `Perkiraan jumlah: ${quantity} pcs`,
        `Spesifikasi: ${notes}`
      ].join('\n');

      // Ganti nomor di bawah dengan nomor WhatsApp resmi BRKH (format internasional, tanpa +).
      const whatsappNumber = '';
      if (!whatsappNumber) {
        window.alert('Form sudah valid. Untuk mengirim otomatis ke WhatsApp, isi nomor WhatsApp resmi BRKH pada variabel whatsappNumber di file script.js.');
        return;
      }
      window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank', 'noopener');
    });
  }

  // Tracking UI demo: requires a backend/database to return real order status.
  const trackingForm = document.querySelector('[data-purpose="tracking-form"]');
  if (trackingForm) {
    trackingForm.addEventListener('submit', event => {
      event.preventDefault();
      const reference = document.getElementById('tracking-reference')?.value.trim();
      if (!reference) return;
      window.alert(`Nomor referensi ${reference} diterima. Fitur pelacakan status memerlukan koneksi ke database/backend.`);
    });
  }
});
